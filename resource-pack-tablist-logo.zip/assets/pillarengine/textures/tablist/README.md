# Logo Texture

Place your tablist logo here as:

```text
logo.png
```

Recommended size: `256x64` or `512x128`, transparent background.
